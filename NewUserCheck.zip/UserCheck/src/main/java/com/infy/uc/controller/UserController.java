package com.infy.uc.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infy.uc.dto.UserDTO;
import com.infy.uc.entity.UserEntity;
//import com.infy.uc.exception.NoSuchUserException;
import com.infy.uc.serv.UserService;

@RestController
@Validated
@RequestMapping("/details")
public class UserController
{
	@Autowired
	UserService serv;
	
	@PostMapping(consumes="application/json")
	public ResponseEntity<String> createuser(@Valid @RequestBody UserDTO ud) //throws NoSuchUserException
	{
		String res=serv.addUser(ud);
		return ResponseEntity.ok(res);
	}
	@GetMapping(value="/active",produces="application/json")
	public List<UserDTO> getDetAct()
	{
		return serv.getDetAct();
	}
	@GetMapping(value="/inactive",produces="application/json")
	public List<UserDTO> getDetInact()
	{
		return serv.getDetInact();
	}
	@GetMapping("/{id}")
	public String getStatus(@PathVariable String id) //throws NoSuchUserException
	{
		return serv.getUserStatus(id);
	}
	@GetMapping("/{id}/{pw}")
	public String Login(@PathVariable String id,@PathVariable String pw)
	{
		return serv.Login(id, pw);
	}
	@DeleteMapping("/{id}")
	public String deleteUser(@PathVariable String id)
	{
		return serv.DeleteUser(id);
	}
	@PostMapping(value="/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file) throws IOException
	{
		File convertfile=new File("D:\\test"+file.getOriginalFilename());
		convertfile.createNewFile();
		FileOutputStream fout=new FileOutputStream(convertfile);
		fout.write(file.getBytes());
		fout.close();
		return new ResponseEntity<>("File is uploaded successfully",HttpStatus.OK);
	}
	@GetMapping(value="/download")
	public ResponseEntity<Object> downloadFile() throws IOException 
	{
		String fname="D:\\puppy haldhi\\pup.jpg";
		File file=new File(fname);
		InputStreamResource resource=new InputStreamResource(new FileInputStream(file));
		HttpHeaders headers=new HttpHeaders();
		headers.add("Content-Disposition",
				String.format("attachment; filename=\"%s\"",file.getName()));
		headers.add("Cache-Control", "no-cache,no-store,must-revalidate");
		headers.add("pragma", "no-cache");
		headers.add("Expires", "0");
		ResponseEntity<Object> responseEntity=ResponseEntity.ok().headers(headers)
											.contentLength(file.length())
											.contentType(MediaType.parseMediaType("application/txt")).body(resource);
		return responseEntity;
	}
	@GetMapping("/adminusage/{un}/{pw}")
	public String adminAccess(@PathVariable String un,@PathVariable String pw)
	{
		String s;
		if(un.equals("admin")&&pw.equals("admin@123"))
			s="You are successfully login as admin";
		else if(un.equals("admin")&&!(pw.equals("admin@123")))
			s="Dear Admin, the password is wrong, please try again.....";
		else
			s="Sorry!!!!this portal is only for admin...";
		return s;
	}
	
	
}