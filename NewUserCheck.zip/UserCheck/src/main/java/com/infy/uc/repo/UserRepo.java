package com.infy.uc.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infy.uc.entity.UserEntity;

@Repository
public interface UserRepo extends JpaRepository<UserEntity,String >{
	@Query(value = "select u from UserEntity u where u.status='active' ")
	List<UserEntity> findByStatusActive();
	@Query(value = "select u from UserEntity u where u.status='inactive' ")
       List<UserEntity> findByStatusInactive();
}
