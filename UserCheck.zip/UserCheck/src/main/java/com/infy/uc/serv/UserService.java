package com.infy.uc.serv;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infy.uc.dto.UserDTO;
import com.infy.uc.entity.UserEntity;

import com.infy.uc.repo.UserRepo;


@Service
public class UserService
{
	@Autowired
	UserRepo repo;
	
	@Autowired
	Environment env;
	public String addUser(UserDTO ud)
	{
		Optional<UserEntity> uent=repo.findById(ud.getId());
		if(uent.isPresent())
			return "user already exists";
			else {
		UserEntity ue=UserEntity.prepareEntity(ud);
		repo.saveAndFlush(ue);
		return "User with "+ud.getId()+" added successfully";}
	}
	
	public List<UserDTO> getDetAct()
	{
		List<UserEntity> ents=repo.findByStatusActive();
		List<UserDTO> dtos=new ArrayList<>();
		for(UserEntity e:ents)
			dtos.add(UserDTO.prepareDTO(e));
		return dtos;
		
	}
	public String getUserStatus(String id) 
	{
		Optional<UserEntity> uent=repo.findById(id);
		if(uent.isPresent())
			return uent.get().getStatus();
		else
		   
	       return "no such user found, try again";
	}
	public List<UserDTO> getDetInact()
	{
		List<UserEntity> ents=repo.findByStatusInactive();
		List<UserDTO> dtos=new ArrayList<>();
		for(UserEntity e:ents)
			dtos.add(UserDTO.prepareDTO(e));
		return dtos;
		
	}
	public String Login(String id,String pw)
	{
		String s="";
		Optional<UserEntity> uent=repo.findById(id);
		if(uent.isPresent())
		{
			if(pw.equals(uent.get().getPw()))
				s="you are succesfully login";
			else
				s="wrong password!!! please try again...";
		}
		else
			s="user not found, please try again";
		return s;
	}
	public String DeleteUser(String id)
	{
		Optional<UserEntity> uent=repo.findById(id);
		if(uent.isPresent()) {
			repo.deleteById(id);
			return "User get deleted";}
		else
		   
	       return "no such user found, try again";
	}
	
}