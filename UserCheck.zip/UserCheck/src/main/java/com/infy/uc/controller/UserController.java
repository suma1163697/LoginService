package com.infy.uc.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.uc.dto.UserDTO;
import com.infy.uc.entity.UserEntity;
//import com.infy.uc.exception.NoSuchUserException;
import com.infy.uc.serv.UserService;

@RestController
@Validated
@RequestMapping("/details")
public class UserController
{
	@Autowired
	UserService serv;
	
	@PostMapping(consumes="application/json")
	public ResponseEntity<String> createuser(@Valid @RequestBody UserDTO ud) //throws NoSuchUserException
	{
		String res=serv.addUser(ud);
		return ResponseEntity.ok(res);
	}
	@GetMapping(value="/active",produces="application/json")
	public List<UserDTO> getDetAct()
	{
		return serv.getDetAct();
	}
	@GetMapping(value="/inactive",produces="application/json")
	public List<UserDTO> getDetInact()
	{
		return serv.getDetInact();
	}
	@GetMapping("/{id}")
	public String getStatus(@PathVariable String id) //throws NoSuchUserException
	{
		return serv.getUserStatus(id);
	}
	@GetMapping("/{id}/{pw}")
	public String Login(@PathVariable String id,@PathVariable String pw)
	{
		return serv.Login(id, pw);
	}
	@DeleteMapping("/{id}")
	public String deleteUser(@PathVariable String id)
	{
		return serv.DeleteUser(id);
	}
	
	
}