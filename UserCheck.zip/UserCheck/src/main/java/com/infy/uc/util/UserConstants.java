package com.infy.uc.util;

public enum UserConstants {
	USER_NOT_FOUND("user.not.found"),
	GENERAL_EXCEPTION_MESSAGE("general.exception"),
	USER_LOGIN_SUCCESS("user.created"),
	USER_DELETED("user.deleted"),
	PASSWORD_UPDATED("user.updated"),
	USER_EXIST("user.already.exist");
	
	private final String type;

	private UserConstants(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return this.type;
	}
	
}
